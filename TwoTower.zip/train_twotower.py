import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from typing import List, Dict
from twotower_model import TwoTower
from data import CustomDataset, ml100k_dataset
import json


device = (
    "cuda"
    if torch.cuda.is_available()
    else "mps"
    if torch.backends.mps.is_available()
    else "cpu"
)
print(f"Using {device} device")

def init_model(conf:Dict):
    model = TwoTower(conf).to(device)
    return model


def train(dataloader, model, loss_fn, optimizer):
    size = len(dataloader.dataset)
    print(size)
    model.train()
    losses = []
    for batch, (X, y) in enumerate(dataloader):
        X, y = (X[0].to(device), X[1].to(device)), y.to(device)

        # Compute prediction error
        pred = model(X)
        loss = loss_fn(pred, y.float())
        losses.append(loss)
        # Backpropagation
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

        if batch % 100 == 0:
            loss, current = loss.item(), (batch + 1) * len(X)
            print(f"loss: {loss:>7f}  [{current:>5d}/{size:>5d}]")

        



def test(dataloader, model, loss_fn):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.eval()
    test_loss, correct = 0, 0
    with torch.no_grad():
        for X, y in dataloader:
            X, y = (X[0].to(device), X[1].to(device)), y.to(device)
            pred = model(X)
            test_loss += loss_fn(pred, y.float()).item()
    test_loss /= num_batches
    print(f"Test Error: \n , Avg loss: {test_loss:>8f} \n")
    return test_loss



def fit(model, train_dataloader, test_dataloader, epochs=5):
    loss_fn = nn.MSELoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=1e-3)
    test_losses = []
    for t in range(epochs):
        print(f"Epoch {t+1}\n-------------------------------")
        train(train_dataloader, model, loss_fn, optimizer)
        test_loss = test(test_dataloader, model, loss_fn)
        test_losses.append(test_loss)

        if test_loss <= min(test_losses):
            torch.save(model.state_dict(), 'best_model.pt')
            print("saved best_model.pt")
    print("Done!")
    


if __name__=="__main__":

    with open('config.json', 'r') as f:
        conf = json.load(f)

    model = init_model(conf)
    df = ml100k_dataset()
    train_data, test_data = train_test_split(df, test_size=0.2)
    user_features = conf["user_features"]
    item_features = conf["item_features"]
    label = conf["label"]

    train_dataloader = DataLoader(CustomDataset(
        train_data,
        user_features,
        item_features,
        label,
        device), batch_size=64, shuffle=True)

    test_dataloader = DataLoader(CustomDataset(
        test_data,
        user_features,
        item_features,
        label,
        device), batch_size=64, shuffle=True)
    
    
    fit(model, train_dataloader, test_dataloader,)